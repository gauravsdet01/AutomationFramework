package com.qa.hubspot.commons;

public class Constants {
	
	
	public final static int PAGE_LOAD_TIME_OUT = 20;
	
	public final static String LOGINPAGE_TITLE = "HubSpot Login";
	
	public final static String HOMEPAGE_TITLE = "Reports dashboard";
	
	public final static String HOMEPAGE_HEADER = "Sales Dashboard";

	public static int DEFAULT_EXPLICIT_WAIT = 20;
	
	
	

}
